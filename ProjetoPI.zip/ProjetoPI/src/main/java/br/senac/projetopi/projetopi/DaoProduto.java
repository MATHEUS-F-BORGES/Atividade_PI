/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.projetopi.projetopi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Matheus
 */
public class DaoProduto {
    
     private Connection obterConexao()
            throws ClassNotFoundException, SQLException {
        Connection conn =null;

        // Passo 1: Registrar driver JDBC
        Class.forName("com.mysql.jdbc.Driver");
        // Passo 2: Obter a conexao
        conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/produtobd",
                "root",
                "bandfm96,1");
        return conn;
    }

 
    public void inserir (Produto produto) throws SQLException, Exception {
        //Monta a string de inserção de um produto no BD,
        //utilizando os dados do produto passados como parâmetro
        String sql = "INSERT INTO produtobd.produto(NOME, DESCRICAO, PRECO_COMPRA, PRECO_VENDA, QUANTIDADE, DT_CADASTRO) VALUES (?, ?, ?, ?, ?, ?)";
       
       
        try (
                Connection conn = obterConexao();
                PreparedStatement stmt = conn.prepareStatement(sql);
            ) {
            
            
            stmt.setString(1, produto.getNome());
            stmt.setString(2, produto.getDescricao());
            stmt.setDouble(3, produto.getPrecoCompra());
            stmt.setDouble(4, produto.getPrecoVenda());
            stmt.setInt(5, produto.getQuantidade());
            stmt.setString(6, " ");
            stmt.execute();
              
            
        } catch (ClassNotFoundException ex) {
            
        } catch (SQLException ex) {
            
        }
    

   
        
    }
        
       
       
    }

